var typescript = require('gulp-tsc');
var gulp = require('gulp');
var tslint = require('gulp-tslint');

gulp.task('tslint-tsc-return', function() {
    return gulp.src(['invalid.ts'])
        .pipe(tslint())
        .pipe(tslint.report('verbose'))
        .pipe(typescript())             // just to show that the file is really read
        .pipe(gulp.dest('./'));
});

gulp.task('tslint-tsc-no-return', function() {
    gulp.src(['invalid.ts'])
        .pipe(tslint())
        .pipe(tslint.report('verbose'))
        .pipe(typescript())             // just to show that the file is really read
        .pipe(gulp.dest('./'));
});

gulp.task('tslint-no-return', function() {
    gulp.src(['invalid.ts'])
        .pipe(tslint())
        .pipe(tslint.report('verbose'));
});

gulp.task('tslint', ['tslint-no-return', 'tslint-tsc-return', 'tslint-tsc-no-return']);
