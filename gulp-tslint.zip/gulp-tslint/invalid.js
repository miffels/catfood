if (true) {
    var a = "foo";
    if (false) {
        ;
    }
}
